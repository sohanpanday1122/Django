from django.contrib import admin
from .models import Employee

# Register your models here.

class EmployeeAdmin(admin.ModelAdmin):

    list_display = ['name','phone','email','address','city','state','pin','payamount','cardholder','cardnumber','month','year','cvv','is_active','created_on']
    
    def save_model(self, request, obj, form, change):
        try:
            super().save_model(request, obj, form, change)
        except Exception as ex:
            print(ex)

admin.site.register(Employee, EmployeeAdmin)
