from django.shortcuts import render
from django.db import IntegrityError
from django.shortcuts import render
from .models import Employee

# from .views import IntegrityError
# Create your views here.
def index(request):
    try:
        __context = {}
        if request.POST:
            try:
                contact = Employee(name=request.POST['name'],
                                   email=request.POST['email'],
                                   phone=request.POST['phone'],
                                   address=request.POST['address'],
                                   city=request.POST['city'],
                                   state=request.POST['state'],
                                   pin=request.POST['pin'],
                                   payamount=request.POST['amount'],
                                   cardholder=request.POST['cardholder'],
                                   cardnumber=request.POST['cardnumber'],
                                   month=request.POST['month'],
                                   year=request.POST['year'],
                                   cvv=request.POST['cvv'])
                contact.save()
                # return redirect(reverse('websites:about'))

                __context[
                    'success'] = "Thankyou, We will back to you as soon as possible!"
            except IntegrityError as ex:
                __context['form_data'] = {
                    'name': request.POST['name'],
                    'email': request.POST['email'],
                    'phone': request.POST['phone'],
                    'address': request.POST['address'],
                    'city': request.POST['city'],
                    'state': request.POST['state'],
                    'pin': request.POST['pin'],
                    'payamount': request.POST['amount'],
                    'cardholder': request.POST['cardholder'],
                    'cardnumber': request.POST['cardnumber'],
                    'month': request.POST['month'],
                    'year': request.POST['year'],
                    'cvv': request.POST['cvv']}


                __context['error'] = ex

        return render(request, 'websites/index.html', __context)
    except Exception as ex:
        return render(request, '404.html', {'error': ex})
