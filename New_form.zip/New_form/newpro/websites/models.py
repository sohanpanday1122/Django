from django.db import models
from django.contrib.auth import settings
# from django.db.models.fields import CharField
from django.utils.timezone import datetime
# Create your models here

class Employee(models.Model):

    objects = models.Manager
     
    name =  models.CharField(max_length=150, primary_key=True)
    email = models.EmailField(max_length=25,unique=True)
    phone = models.CharField(max_length=10, null=True, blank=True)
    address = models.CharField(max_length=200, null=True, blank=True)
    city = models.CharField(max_length=50)
    state = models.CharField(max_length=200)
    pin = models.CharField(max_length=150, null=True, blank=True)
    payamount = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    cardholder = models.CharField(max_length=150)
    cardnumber = models.CharField(max_length=16)
    month = models.CharField(max_length=5)
    year = models.CharField(max_length=5)
    cvv = models.CharField(max_length=3)

    is_active = models.BooleanField(
        default=True, null=True, blank=True, editable=False)
    # created_by = models.ForeignKey(
    #     settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True, editable=False)
    created_on = models.DateField(default=datetime.now, editable=False)

    class Meta:
        verbose_name_plural = "Employee"
        verbose_name = "Employees"
    def __str__(self):
        return self.name
